# set working directory to the script's directory
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# installing necessary packages
if (!require("dplyr")) 
  BiocManager::install("dplyr")
if (!require("ggplot2")) 
  BiocManager::install("ggplot2")
if (!require("ggforce")) 
  BiocManager::install("ggforce")

library(dplyr)
library(ggplot2)
library(ggforce)

##################User Inputs#######################

##Gene expression files
###remember to set working directory to source or use full file path
left <- read.csv("Study1.csv")
right <- read.csv("Study2.csv")

##Right (r), Left (l), and Middle (m) circle colors
r_col_upreg = "#7FD7F7"
r_col_downreg = "#528AA1"

l_col_upreg = "#FBEF49"
l_col_downreg = "#EAA407"

m_col_upreg = "#9353AF"
m_col_downreg = "#501b6b"

##Circle arrangement variables. default "nudge" is -0.1
l_x_offset = 0
l_y_offset = 0
nudge = -0.1

##draw encompassing circle. Either TRUE or FALSE
draw_e_circle <- TRUE

##angle of lines for circle center; default is 45
line_angle = 45

#TEXT OPTIONS
##text coloring 0 = use existing palette; 1 = black
text_color_strategy = 1

##text formatting 0 = normal, 1 = bold
text_formatting = 1

##scaling text default is 11. units are "pts" like in microsoft word.
m_b_text = 12
m_r_text = 12
m_l_text = 12
m_t_text = 12
l_t_text = 16
l_b_text = 16
r_t_text = 16
r_b_text = 16

##text padding default is 0
r_x_padding = -.5
r_y_padding = 0
l_x_padding = 0
l_y_padding = 0
m_h_padding = .1
m_v_padding = -.05

##draw text. Either TRUE or FALSE
draw_text <- TRUE

###################END USER INPUTS############################



make_line <- function(x_min,x_max,x_center,y,slope){
  line_intercept <- slope*(-1*m_x_center) + l_y_offset
  pts <- tibble(
    x = seq(x_min,x_max,by = (x_max-x_min)/100),
  )
  pts$y = slope*pts$x+line_intercept
  return(pts)
}

arrange_circle_radii <- function(){
  ratio <- l_num_total / r_num_total
  area_base <- pi*(2**2)
  area_max <- area_base*ratio
  radius_max <- sqrt(area_max/pi)
  radii <- c("left" = radius_max,"right" = 2)
  return(radii)
}

make_tibb <- function(radius,x_offset,y_cut,both=FALSE){
  c_pts <- tibble(
    deg = 0:360,
    r = radius,
    x = r * cos((deg * pi)/180)+x_offset, 
    y = r * sin((deg * pi)/180)
  )
  if (both == TRUE){
    c_pts = c_pts
  }else if (y_cut > 0){
    c_pts = filter(c_pts, y >= y_cut)
  }else{
    c_pts = filter(c_pts, y <= y_cut)
  }
  return(c_pts)
}

arrange_colors <- function(upreg,downreg,y_cut){
  if (y_cut > 0){
    return(c(downreg,upreg))
  } else{
    return(c(upreg,downreg))
  }
}

##read input data
joined <- full_join(right,left,by = c('Gene'))
shared <- filter(joined,!(is.na(Treatment.x)) &!(is.na(Treatment.y)))
shared_up <- filter(shared,Change.x == "Up" & Change.y == "Up")
shared_down <- filter(shared,Change.x == "Down" & Change.y == "Down")
shared_lu_rd <- filter(shared,Change.x == "Up" & Change.y == "Down")
shared_ld_ru <- filter(shared,Change.x == "Down" & Change.y == "Up")
right_exclusive <- filter(right,!(Gene %in% shared$Gene))
right_exclusive_down <- filter(right_exclusive,Change == "Down")
left_exclusive <- filter(left,!(Gene %in% shared$Gene))
left_exclusive_down <- filter(left_exclusive,Change == "Down")

##Define left circle
l_num_total = nrow(left_exclusive)
l_num_downregulated = nrow(left_exclusive_down)
l_num_upregulated = l_num_total - l_num_downregulated
l_percent_downregulated = l_num_downregulated/l_num_total

#Define right circle
r_num_total = nrow(right_exclusive)
r_num_downregulated = nrow(right_exclusive_down)
r_num_upregulated = r_num_total - r_num_downregulated
r_percent_downregulated = r_num_downregulated/r_num_total

#get radii & scale circles
radii <- arrange_circle_radii()
l_radius = radii['left']
r_radius = radii['right']

#arrange circle centers
if (l_radius >= r_radius){
  r_x_offset <- l_radius + (r_radius*(0.2+nudge))
}else{
  r_x_offset <- r_radius + (l_radius*(0.2+nudge))
}
r_y_offset = l_y_offset

#calculate left circle features
l_y_cut = ((l_radius*2)*(l_percent_downregulated-0.5))
l_pts <- make_tibb(l_radius,l_x_offset,l_y_cut)
l_col <- arrange_colors(l_col_upreg,l_col_downreg,l_y_cut)
l_upreg_txt_pos <- c(l_x_offset,((l_radius+l_y_cut)/2))
l_downreg_txt_pos <- c(l_x_offset,((-l_radius+l_y_cut)/2))

#calculate right circle features
r_y_cut = ((r_radius*2)*(r_percent_downregulated-0.5))
r_pts <- make_tibb(r_radius,r_x_offset,r_y_cut)
r_col <- arrange_colors(r_col_upreg,r_col_downreg,r_y_cut)
r_upreg_txt_pos <- c(r_x_offset,((r_radius+r_y_cut)/2))
r_downreg_txt_pos <- c(r_x_offset,((-r_radius+r_y_cut)/2))

#build the middle background
m_shared_upreg = nrow(shared_up)
m_shared_downreg = nrow(shared_down)
m_l_only_upreg = nrow(shared_lu_rd)
m_r_only_upreg = nrow(shared_ld_ru)
R = sqrt((r_x_offset-l_x_offset)**2+(r_y_offset+l_y_offset)**2)
diff_dia = r_radius**2-l_radius**2
sum_dia = r_radius**2+l_radius**2
pos_y_intersect = 0.5*(r_y_offset+l_y_offset) + ((diff_dia)/(2*R**2)) * (r_y_offset-l_y_offset)*-1 - 
  0.5*sqrt((2*sum_dia/R**2)-((diff_dia**2)/R**4)-1)*(r_x_offset-l_x_offset)*-1
neg_y_intersect = 0.5*(r_y_offset+l_y_offset) + ((diff_dia)/(2*R**2)) * (r_y_offset-l_y_offset)*-1 - 
  0.5*sqrt((2*sum_dia/R**2)-((diff_dia**2)/R**4)-1)*(r_x_offset-l_x_offset)*1
x_intersect = 0.5*(r_x_offset+l_x_offset) + ((diff_dia)/(2*R**2)) * (r_x_offset-l_x_offset)*-1 - 
  0.5*sqrt((2*sum_dia/R**2)-((diff_dia**2)/R**4)-1)*(r_y_offset-l_y_offset)*1
#middle-left-plot
ml_pts <- make_tibb(r_radius,r_x_offset,r_y_cut,TRUE)
ml_pts <- filter(ml_pts, y <= pos_y_intersect & y > 0 & x <= (x_intersect+0.6))
#middle-right-plot
mr_pts <- make_tibb(l_radius,l_x_offset,l_y_cut,TRUE)
mr_pts <- filter(mr_pts, y <= pos_y_intersect & y > 0 & x >= 0.4)
m_pts <- bind_rows(ml_pts,mr_pts)

#find center of overlap
m_x_center <- mean(c(max(m_pts$x),min(m_pts$x)))

#make the lines
x_min = min(m_pts$x)
x_max = max(m_pts$x)
slope = tan(line_angle)
line_y_intercept <- slope*(-1*m_x_center) + l_y_offset
line_right_x <- ((-1*line_y_intercept*slope)+l_x_offset+(slope*l_y_offset)+
  sqrt((-1*line_y_intercept**2)+(1+slope**2)*l_radius**2-((-1*slope*l_x_offset)+l_y_offset)**2+
         (line_y_intercept*((-2*slope*l_x_offset)+(2*slope*l_y_offset)))))/(1+slope**2)
line_right_upper_y <- slope*line_right_x+line_y_intercept
line_right_lower_y <- line_right_upper_y*-1
line_left_x <- ((-1*line_y_intercept*slope)+r_x_offset+(slope*r_y_offset)-
                 sqrt((-1*line_y_intercept**2)+(1+slope**2)*r_radius**2-((-1*slope*r_x_offset)+r_y_offset)**2+
                        (line_y_intercept*((-2*slope*r_x_offset)+(2*slope*r_y_offset)))))/(1+slope**2)
line_left_lower_y <- slope*line_left_x+line_y_intercept
line_left_upper_y <- line_left_lower_y * -1
line_pos <- tibble(
  x = c(line_right_x,line_left_x),
  y = c(line_right_upper_y,line_left_lower_y)
)
line_neg <- tibble(
  x = c(line_right_x,line_left_x),
  y = c(line_right_lower_y,line_left_upper_y)
)

#find center of each section
#middle_left_section (upreg in L downreg in R)
m_l_ml_x = mean(c(m_x_center,min(ml_pts$x)))
m_l_ml_y = l_y_offset

#middle_right_section (upreg in R downreg in L)
m_r_mr_x = mean(c(m_x_center,max(mr_pts$x)))
m_r_mr_y = r_y_offset

#middle_top_section (upreg in both)
m_t_mt_x = m_x_center
m_t_mt_y = mean(c(l_y_offset,max(m_pts$y)))

#middle_bottom_section (downreg in both)
m_b_mb_x = m_x_center
m_b_mb_y = mean(c(l_y_offset,-1*max(m_pts$y)))

#color the bottom middle section differently
m_x_to_shade <- filter(m_pts, x >= line_left_x & x <= line_right_x)
m_y_leftline <- filter(m_pts, x >= line_left_x & x <= m_x_center)
m_y_rightline <- filter(m_pts, x <= line_right_x & x >= m_x_center)
m_y_leftline$y_cut <- slope*m_y_leftline$x+line_y_intercept
m_y_rightline$y_cut <- (-1*slope)*m_y_rightline$x+(-1*line_y_intercept)
m_x_to_shade_2 <- bind_rows(m_y_leftline,m_y_rightline)

#encompassing circle
e_center_x <- mean(c((l_x_offset - l_radius),(r_x_offset + r_radius)))
e_rad = e_center_x-(l_x_offset - l_radius)

#set up text colors and options
if(text_color_strategy == 0){ #text color option 0
  l_upreg_text_col = l_col_upreg
  l_downreg_text_col = l_col_downreg
  r_upreg_txt_col = r_col_upreg
  r_downreg_txt_col = r_col_downreg
  m_l_text_col = l_col_downreg
  m_r_text_col = r_col_downreg
  m_t_text_col = m_col_downreg
  m_b_text_col = m_col_upreg
}else{ #text color option 1
  l_upreg_text_col = "black"
  l_downreg_text_col = "black"
  r_upreg_txt_col = "black"
  r_downreg_txt_col = "black"
  m_l_text_col = "black"
  m_r_text_col = "black"
  m_t_text_col = "black"
  m_b_text_col = "black"
}
if(text_formatting==1){
  text_format = "bold"
}else{
  text_format = ""
}

#build the plot
p <- ggplot() +
  geom_circle(
    aes(x0 = l_x_offset, y0 = l_y_offset, r = l_radius), 
    fill = l_col[1], 
    color = NA
  ) +
  geom_ribbon(
    data = l_pts, 
    aes(x, ymin = y, ymax = l_y_cut), 
    fill = l_col[2], 
    color = NA
  ) +
  geom_circle(
    aes(x0 = r_x_offset, y0 = r_y_offset, r = r_radius), 
    fill = r_col[1], 
    color = NA
  ) +
  geom_ribbon(
    data = r_pts, 
    aes(x, ymin = y, ymax = r_y_cut), 
    fill = r_col[2], 
    color = NA
  )+
  geom_ribbon(
    data = m_pts, 
    aes(x, ymin = y*-1, ymax = y), 
    fill = m_col_upreg, 
    color = NA
  )+
  geom_ribbon(
    data = m_x_to_shade_2,
    aes(x,ymin = (-1*y), ymax = y_cut),
    fill = m_col_downreg,
    color = NA
  )+
  geom_line(
    data = line_pos,
    aes(x=x,y=y)
  )+
  geom_line(
    data = line_neg,
    aes(x=x,y=y)
  )+
  theme_void()+
  coord_fixed()

if(draw_e_circle == TRUE){
  p <- p+
    geom_circle(
      aes(x0 = e_center_x, y0 = l_y_offset, r = e_rad),
      fill = NA,
      color = "black")
}

if(draw_text == TRUE){
  p<- p + 
    annotate(geom="text",
             x = l_upreg_txt_pos[1] - l_x_padding,
             y = l_upreg_txt_pos[2] + l_y_padding,
             label = l_num_upregulated,
             color = l_col_downreg,
             size = l_t_text*0.35,
             fontface = text_format)+
    annotate(geom="text",
             x = l_downreg_txt_pos[1] - l_x_padding,
             y = l_downreg_txt_pos[2] - l_y_padding,
             label = l_num_downregulated,
             color = l_col_upreg,
             size = l_b_text*0.35,
             fontface = text_format)+
    annotate(geom="text",
             x = r_upreg_txt_pos[1] - r_x_padding,
             y = r_upreg_txt_pos[2] + r_y_padding,
             label = r_num_upregulated,
             color = r_col_downreg,
             size = r_t_text*0.35,
             fontface = text_format)+
    annotate(geom="text",
             x = r_downreg_txt_pos[1] - r_x_padding,
             y = r_downreg_txt_pos[2] - r_y_padding,
             label = r_num_downregulated,
             color = r_col_upreg,
             size = r_b_text*0.35,
             fontface = text_format)+
    annotate(geom="text",
             x = m_l_ml_x - m_h_padding,
             y = m_l_ml_y,
             label = m_l_only_upreg,
             color = l_col_downreg,
             size = m_l_text*0.35,
             fontface = text_format)+
    annotate(geom="text",
             x = m_r_mr_x + m_h_padding,
             y = m_r_mr_y,
             label = m_r_only_upreg,
             color = r_col_downreg,
             size = m_r_text*0.35,
             fontface = text_format)+
    annotate(geom="text",
             x = m_t_mt_x,
             y = m_t_mt_y + m_v_padding,
             label = m_shared_upreg,
             color = m_col_downreg,
             size = m_t_text*0.35,
             fontface = text_format)+
    annotate(geom="text",
             x = m_b_mb_x,
             y = m_b_mb_y - m_v_padding,
             label = m_shared_downreg,
             color = m_col_upreg,
             size = m_b_text*0.35,
             fontface = text_format)
  plot(p)
}else{
  plot(p)
  print("NUMBERS FOR LABELS")
  print(sprintf("Left Upregulated: %i",l_num_upregulated))
  print(sprintf("Left Downregulated: %i",l_num_downregulated))
  print(sprintf("Right Upregulated: %i",r_num_upregulated))
  print(sprintf("Right Downregulated: %i",r_num_downregulated))
  print(sprintf("Shared, Left quadrant Upregulated: %i",m_l_only_upreg))
  print(sprintf("Shared, Right quadrant Upregulated: %i",m_r_only_upreg))
  print(sprintf("Shared, Top quadrant Upregulated: %i",m_shared_upreg))
  print(sprintf("Shared, Bottom quadrant Downregulated: %i", m_shared_downreg))
}
